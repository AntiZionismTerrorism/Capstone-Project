﻿## Project Overview

Welcome to my capstone project in the ML Nanodegree! The goal of this project is to make classifier capable of taking an image of Flower and predict its respective category. 
## Project Instructions

### Instructions

1. (Optional) Download the original [flowers dataset](https://www.kaggle.com/alxmamaev/flowers-recognition). 

2. Download my version of the data after take a subset of the training  data  to be used as validation and test data. [my flower dataset](https://github.com/AntiZionismTerrorism/flowers_data).
Unzip the folders of mytrain1 ,mytrain2 , mytrain3 , mytrain4 and mytrain5 and place all 5 subfolders in the repo, at location `path/to/Capstone Project/flower-project/data/flower_images/mytrain`.
Unzip the folder of myvalid and place all 5 subfolders in the repo, at location `path/to/Capstone Project/flower-project/data/flower_images/myvalid`.
Unzip the folder my test  and place all 5 subfolders in the repo, at location `path/to/Capstone Project/flower-project/data/flower_images/test`.
If you are using a Windows machine, you are encouraged to use [7zip](http://www.7-zip.org/) to extract the folder. 

3. (Optional) __If you plan to install TensorFlow with GPU support on your local machine__, follow [the guide](https://www.tensorflow.org/install/) to install the necessary NVIDIA software on your system.  If you are using an EC2 GPU instance, you can skip this step.

4. (Optional) **If you are running the project on your local machine (and not using AWS)**, create (and activate) a new environment.

	- __Linux__ (to install with __GPU support__, change `requirements/flower-linux.yml` to `requirements/flower-linux-gpu.yml`): 
	```
	conda env create -f requirements/flower-linux.yml
	source activate flower-project
	```  
	- __Mac__ (to install with __GPU support__, change `requirements/flower-mac.yml` to `requirements/flower-mac-gpu.yml`): 
	```
	conda env create -f requirements/flower-mac.yml
	source activate flower-project
	```  
	**NOTE:** Some Mac users may need to install a different version of OpenCV
	```
	conda install --channel https://conda.anaconda.org/menpo opencv3
	```
	- __Windows__ (to install with __GPU support__, change `requirements/flower-windows.yml` to `requirements/flower-windows-gpu.yml`):  
	```
	conda env create -f requirements/flower-windows.yml
	activate flower-project
	```

7. (Optional) **If you are running the project on your local machine (and not using AWS)** and Step 6 throws errors, try this __alternative__ step to create your environment.

	- __Linux__ or __Mac__ (to install with __GPU support__, change `requirements/requirements.txt` to `requirements/requirements-gpu.txt`): 
	```
	conda create --name flower-project python=3.5
	source activate flower-project
	pip install -r requirements/requirements.txt
	```
	**NOTE:** Some Mac users may need to install a different version of OpenCV
	```
	conda install --channel https://conda.anaconda.org/menpo opencv3
	```
	- __Windows__ (to install with __GPU support__, change `requirements/requirements.txt` to `requirements/requirements-gpu.txt`):  
	```
	conda create --name flower-project python=3.5
	activate flower-project
	pip install -r requirements/requirements.txt
	```
	
8. (Optional) **If you are using AWS**, install Tensorflow.
```
sudo python3 -m pip install -r requirements/requirements-gpu.txt
```
	
9. Switch [Keras backend](https://keras.io/backend/) to TensorFlow.
	- __Linux__ or __Mac__: 
		```
		KERAS_BACKEND=tensorflow python -c "from keras import backend"
		```
	- __Windows__: 
		```
		set KERAS_BACKEND=tensorflow
		python -c "from keras import backend"
		```

10. (Optional) **If you are running the project on your local machine (and not using AWS)**, create an [IPython kernel](http://ipython.readthedocs.io/en/stable/install/kernel_install.html) for the `flower-project` environment. 
```
python -m ipykernel install --user --name flower-project --display-name "flower-project"
```

11. Open the notebook.
```
jupyter notebook flower_app.ipynb
```

12. (Optional) **If you are running the project on your local machine (and not using AWS)**, before running code, change the kernel to match the flower-project environment by using the drop-down menu (**Kernel > Change kernel > flower-project**).